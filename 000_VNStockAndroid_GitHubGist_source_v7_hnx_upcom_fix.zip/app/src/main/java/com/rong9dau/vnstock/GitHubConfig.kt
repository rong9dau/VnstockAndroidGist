package com.rong9dau.vnstock

object GitHubConfig {
    const val CLIENT_ID = "Ov23lioj7j6wnBR0mfrm"
    const val GIST_DESCRIPTION = "VNStock Android Portfolio"
    const val GIST_FILE = "portfolio.json"
}

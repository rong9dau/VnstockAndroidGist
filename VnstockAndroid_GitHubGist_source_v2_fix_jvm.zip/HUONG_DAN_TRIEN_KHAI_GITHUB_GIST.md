# HƯỚNG DẪN TRIỂN KHAI VNStock Android - GitHub Login + Private Gist

Bản này không dùng Firebase. App đăng nhập GitHub bằng Device Flow và lưu dữ liệu vào private Gist.

Client ID đã dán sẵn:

```text
Ov23lioj7j6wnBR0mfrm
```

## 1. Kiểm tra GitHub OAuth App

Mở:

```text
https://github.com/settings/developers
```

Vào OAuth Apps → app VNStock Android. Bật **Enable Device Flow** nếu có.

## 2. Upload source lên GitHub

Tạo repo mới, ví dụ:

```text
VnstockAndroidGist
```

Upload toàn bộ file trong ZIP vào gốc repo. Không cần Firebase, không cần google-services.json.

## 3. Build APK

Vào repo → Actions → Build Android APK → Run workflow.

Build xong, tải artifact:

```text
VNStock-GitHub-Gist-debug-apk
```

Trong đó có file `app-debug.apk`.

## 4. Cài app

Tải APK về Android → mở file → cho phép cài app không rõ nguồn → Install.

## 5. Đăng nhập

Mở app → Đăng nhập GitHub → app hiện mã → trình duyệt GitHub mở → nhập mã → Authorize.

App sẽ tạo private Gist tên:

```text
VNStock Android Portfolio
```

File dữ liệu:

```text
portfolio.json
```

## 6. Dùng nhiều thiết bị

Cài cùng APK trên thiết bị khác, đăng nhập cùng GitHub, app tải lại danh mục từ private Gist.

## 7. Lưu ý

Khi GitHub hỏi quyền, cần cấp quyền `gist`. Nếu lỡ từ chối hoặc thiếu quyền, vào GitHub Settings → Applications → Authorized OAuth Apps → Revoke app VNStock Android rồi đăng nhập lại.


## Bản v2 sửa lỗi build JVM target

Nếu GitHub Actions báo:

```text
Inconsistent JVM-target compatibility detected for tasks
compileDebugJavaWithJavac (1.8) and compileDebugKotlin (17)
```

Bản v2 đã sửa trong:

```text
app/build.gradle.kts
```

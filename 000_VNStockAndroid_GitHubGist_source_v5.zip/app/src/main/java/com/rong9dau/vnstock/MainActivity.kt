package com.rong9dau.vnstock

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.view.Gravity
import android.widget.*
import com.google.gson.Gson
import kotlinx.coroutines.*
import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.time.LocalDate
import java.time.ZoneOffset
import java.util.Locale
import java.util.concurrent.TimeUnit

data class Holding(var code:String="", var exchange:String="HOSE", var sector:String="Chưa rõ", var qty:Double=0.0, var cost:Double=0.0, var manualPrice:Double=0.0)
data class Price(var price:Double=0.0, var prevClose:Double=0.0, var change:Double=0.0, var volume:Double=0.0, var date:String="", var source:String="")
data class AppState(var holdings:MutableList<Holding> = mutableListOf(), var prices:MutableMap<String,Price> = mutableMapOf())
data class DeviceCode(val device:String, val user:String, val uri:String, val expires:Int, val interval:Int)
data class CalcRow(val h:Holding, val p:Price, val value:Double, val capital:Double, val pl:Double, val plPct:Double, val day:Double)

class MainActivity: Activity(){
    private val gson=Gson()
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main)
    private val http=OkHttpClient.Builder().connectTimeout(18,TimeUnit.SECONDS).readTimeout(22,TimeUnit.SECONDS).build()
    private lateinit var root:LinearLayout
    private lateinit var content:LinearLayout
    private var state=AppState()
    private var offline=false
    private var tab="dashboard"
    private val sectors=mapOf("VHM" to "Bất động sản","VIC" to "Bất động sản","FPT" to "Công nghệ thông tin","HPG" to "Thép","VCB" to "Ngân hàng","BID" to "Ngân hàng","CTG" to "Ngân hàng","TCB" to "Ngân hàng","MBB" to "Ngân hàng","ACB" to "Ngân hàng","STB" to "Ngân hàng","VPB" to "Ngân hàng","HDB" to "Ngân hàng","SHB" to "Ngân hàng","ABB" to "Ngân hàng","SSI" to "Chứng khoán","VND" to "Chứng khoán","HCM" to "Chứng khoán","VCI" to "Chứng khoán","MBS" to "Chứng khoán","SHS" to "Chứng khoán","GAS" to "Dầu khí","PLX" to "Dầu khí","PVD" to "Dầu khí","PVS" to "Dầu khí","MWG" to "Bán lẻ","FRT" to "Bán lẻ","DGW" to "Bán lẻ","PNJ" to "Bán lẻ","GMD" to "Cảng biển - logistics","HAH" to "Vận tải biển","REE" to "Điện - nước","POW" to "Điện","DGC" to "Hóa chất","DCM" to "Phân bón","DPM" to "Phân bón")

    override fun onCreate(b:Bundle?){ super.onCreate(b); loadLocal(); if(token()!=null){ offline=false; showMain(); loadGist() } else showAuth() }
    override fun onDestroy(){ super.onDestroy(); scope.cancel() }

    private fun showAuth(){
        root=vertical(); root.setBackgroundColor(Color.rgb(245,247,251)); setContentView(root)
        val c=card(); c.addView(title("VNStock Android")); c.addView(txt("Đăng nhập GitHub để đồng bộ bằng private Gist. Không cần Firebase.",14,Color.DKGRAY))
        val login=btn("Đăng nhập GitHub",primary()); val off=btn("Dùng offline",gray()); val row=horiz(); row.addView(login,weight()); row.addView(off,weight()); c.addView(row)
        val msg=txt("",14,Color.DKGRAY); c.addView(msg); root.addView(c)
        login.setOnClickListener{ githubLogin(msg) }; off.setOnClickListener{ offline=true; showMain() }
    }

    private fun githubLogin(msg:TextView){ scope.launch{ try{
        msg.text="Đang lấy mã GitHub..."; val d=withContext(Dispatchers.IO){deviceCode()}
        msg.text="Mã: ${d.user}\nTrình duyệt sẽ mở GitHub. Nhập mã và bấm Authorize."
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(d.uri)))
        val t=withContext(Dispatchers.IO){pollToken(d)}; saveToken(t); offline=false; showMain(); loadGist()
    }catch(e:Exception){ msg.text="Lỗi: ${e.message}" } } }

    private fun showMain(){
        root=vertical(); root.setBackgroundColor(Color.rgb(245,247,251)); setContentView(root)
        val head=vertical(); head.setBackgroundColor(primary()); head.setPadding(dp(14),dp(12),dp(14),dp(10)); root.addView(head)
        head.addView(txt("VNStock Android",22,Color.WHITE,true)); head.addView(txt(if(offline)"Offline" else "GitHub Gist Sync",13,Color.WHITE))
        val scrollTabs=HorizontalScrollView(this); val tabs=horiz(); scrollTabs.addView(tabs); head.addView(scrollTabs)
        listOf("dashboard" to "Tổng quan","portfolio" to "Danh mục","settings" to "Cài đặt").forEach{(id,name)-> val b=btn(name, if(id==tab) Color.WHITE else Color.rgb(13,148,136)); b.setTextColor(if(id==tab) primary() else Color.WHITE); b.setOnClickListener{tab=id; showMain()}; tabs.addView(b, LinearLayout.LayoutParams(-2,dp(42)).apply{setMargins(0,dp(8),dp(8),0)}) }
        val sv=ScrollView(this); content=vertical(); sv.addView(content); root.addView(sv,LinearLayout.LayoutParams(-1,0,1f))
        when(tab){"portfolio"->portfolio();"settings"->settings();else->dashboard()}
    }

    private fun dashboard(){ content.removeAllViews(); val action=card(); val row=horiz(); val fetch=btn("Cập nhật giá",primary()); val save=btn("Lưu Gist",blue()); row.addView(fetch,weight()); row.addView(save,weight()); action.addView(row); content.addView(action); fetch.setOnClickListener{fetchAll()}; save.setOnClickListener{saveCloud()}
        val rows=calcRows(); val capital=rows.sumOf{it.capital}; val value=rows.sumOf{it.value}; val pl=rows.sumOf{it.pl}; val day=rows.sumOf{it.day}
        val grid=vertical(); val r1=horiz(); val r2=horiz(); r1.addView(metric("Tổng giá vốn",money(capital)),weight()); r1.addView(metric("Giá trị",money(value)),weight()); r2.addView(metric("Lãi/lỗ",money(pl)+" ("+pct(if(capital>0)pl/capital else 0.0)+")",pl),weight()); r2.addView(metric("Phiên",money(day),day),weight()); grid.addView(r1); grid.addView(r2); content.addView(grid)
        val list=card(); list.addView(sub("Danh mục")); if(rows.isEmpty()) list.addView(txt("Chưa có mã. Vào tab Danh mục để thêm.",14,Color.DKGRAY)); rows.sortedByDescending{it.value}.forEach{r-> list.addView(txt("${r.h.code} · ${r.h.sector}\nSL ${money(r.h.qty)} · Giá ${money(r.p.price)} · Giá trị ${money(r.value)}\nLãi/lỗ ${money(r.pl)} (${pct(r.plPct)}) · Phiên ${money(r.day)} · ${r.p.source}",14, if(r.pl>=0) green() else red())); list.addView(line()) }; content.addView(list) }

    private fun portfolio(){ content.removeAllViews(); val form=card(); form.addView(sub("Thêm / sửa danh mục")); val code=input("Mã CP"); val exch=Spinner(this); exch.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("HOSE","HNX","UPCOM","OTHER")); val sector=input("Ngành"); val qty=input("Số lượng"); val cost=input("Giá vốn TB"); val manual=input("Giá thủ công nếu API lỗi"); listOf(label("Mã CP"),code,label("Sàn"),exch,label("Ngành"),sector,label("Số lượng"),qty,label("Giá vốn TB"),cost,label("Giá thủ công"),manual).forEach{form.addView(it)}; val add=btn("Thêm / cập nhật",primary()); form.addView(add); content.addView(form)
        fun fill(h:Holding){ code.setText(h.code); sector.setText(h.sector); qty.setText(trim(h.qty)); cost.setText(trim(h.cost)); manual.setText(if(h.manualPrice>0)trim(h.manualPrice) else ""); exch.setSelection(listOf("HOSE","HNX","UPCOM","OTHER").indexOf(h.exchange).coerceAtLeast(0)) }
        add.setOnClickListener{ val c=clean(code.text.toString()); val q=num(qty.text.toString()); val co=num(cost.text.toString()); if(c.isBlank()||q<=0||co<=0){toast("Nhập mã, SL, giá vốn");return@setOnClickListener}; val h=Holding(c,exch.selectedItem.toString(), sector.text.toString().trim().ifBlank{sectors[c]?:"Chưa rõ"}, q, co, num(manual.text.toString())); val idx=state.holdings.indexOfFirst{it.code==c}; if(idx>=0)state.holdings[idx]=h else state.holdings.add(h); if(h.manualPrice>0)state.prices[h.code]=Price(h.manualPrice, source="Thủ công", date=today()); saveCloud(); showMain() }
        val list=card(); list.addView(sub("Danh mục hiện tại")); val fetch=btn("Cập nhật giá toàn bộ",blue()); list.addView(fetch); fetch.setOnClickListener{fetchAll()}; calcRows().forEach{r-> val box=vertical(); box.setPadding(0,dp(8),0,dp(8)); box.addView(txt("${r.h.code} · ${r.h.exchange} · ${r.h.sector}\nSL ${money(r.h.qty)} · Vốn ${money(r.h.cost)} · Giá ${money(r.p.price)}\nGiá trị ${money(r.value)} · Lãi/lỗ ${money(r.pl)} (${pct(r.plPct)})",14, if(r.pl>=0) green() else red())); val br=horiz(); val edit=btn("Sửa",gray()); val del=btn("Xóa",red()); br.addView(edit,weight()); br.addView(del,weight()); box.addView(br); edit.setOnClickListener{fill(r.h)}; del.setOnClickListener{state.holdings.removeAll{it.code==r.h.code}; state.prices.remove(r.h.code); saveCloud(); showMain()}; list.addView(box); list.addView(line()) }; content.addView(list) }

    private fun settings(){ content.removeAllViews(); val c=card(); c.addView(sub("GitHub Gist Sync")); c.addView(txt("Dữ liệu lưu trong private Gist: ${GitHubConfig.GIST_DESCRIPTION}",14,Color.DKGRAY)); val load=btn("Tải từ Gist",blue()); val save=btn("Lưu lên Gist",primary()); val share=btn("Chia sẻ backup JSON",gray()); val logout=btn("Đăng xuất GitHub",red()); listOf(load,save,share,logout).forEach{c.addView(it)}; content.addView(c); load.setOnClickListener{loadGist()}; save.setOnClickListener{saveCloud()}; share.setOnClickListener{shareBackup()}; logout.setOnClickListener{clearToken(); offline=false; showAuth()} }

    private fun fetchAll(){ if(state.holdings.isEmpty()){toast("Chưa có danh mục");return}; toast("Đang cập nhật giá..."); scope.launch{ var ok=0; val fail=mutableListOf<String>(); for(h in state.holdings){ try{state.prices[h.code]=fetchPrice(h); ok++}catch(e:Exception){fail.add(h.code)} }; saveCloud(); showMain(); toast(if(fail.isEmpty())"Fetch xong $ok mã" else "Fetch $ok mã, lỗi: ${fail.joinToString(", ")}") } }
    private suspend fun fetchPrice(h:Holding):Price{ val bars=fetchBars(h.code,h.exchange); val last=bars.last(); val prev=bars.getOrNull(bars.size-2); val pc=prev?.close?:0.0; return Price(last.close,pc,if(pc>0)last.close-pc else 0.0,last.volume,last.date,"API") }
    data class Bar(val date:String,val close:Double,val volume:Double)
    private suspend fun fetchBars(code:String, exchange:String):List<Bar>{ val errs=mutableListOf<String>(); try{return vndirect(code)}catch(e:Exception){errs.add("VNDIRECT: "+(e.message?:"lỗi"))}; try{return tcbs(code)}catch(e:Exception){errs.add("TCBS: "+(e.message?:"lỗi"))}; try{return yahoo(code,exchange)}catch(e:Exception){errs.add("YAHOO: "+(e.message?:"lỗi"))}; throw Exception(errs.joinToString(" | ")) }
    private suspend fun vndirect(code:String)=withContext(Dispatchers.IO){ val from=LocalDate.now().minusDays(60).toString(); val j=JSONObject(get("https://finfo-api.vndirect.com.vn/v4/stock_prices?sort=date:asc&q=code:$code~date:gte:$from&size=200")); val a=j.optJSONArray("data")?:JSONArray(); val out=mutableListOf<Bar>(); for(i in 0 until a.length()){val o=a.optJSONObject(i)?:continue; val d=o.optString("date",o.optString("tradingDate")).take(10); val c=num(o,"close","adClose","price","last","matchPrice"); if(d.isNotBlank()&&c>0) out.add(Bar(d,c,num(o,"volume","nmVolume","accumulatedVolume","totalVolume")))}; if(out.isEmpty())throw Exception("VNDIRECT empty"); out.takeLast(10) }
    private suspend fun tcbs(code:String)=withContext(Dispatchers.IO){ val to=System.currentTimeMillis()/1000; val from=to-86400*80; val url="https://apipubaws.tcbs.com.vn/stock-insight/v1/stock/bars-long-term?ticker=$code&type=stock&resolution=D&from=$from&to=$to"; val any=org.json.JSONTokener(get(url)).nextValue(); val arr=if(any is JSONObject) any.optJSONArray("data")?:any.optJSONArray("bars")?:JSONArray() else any as JSONArray; val out=mutableListOf<Bar>(); for(i in 0 until arr.length()){val o=arr.optJSONObject(i)?:continue; val d=o.optString("tradingDate",o.optString("date",o.optString("time"))).take(10); val c=num(o,"close","c"); if(d.isNotBlank()&&c>0)out.add(Bar(d,c,num(o,"volume","v")))}; if(out.isEmpty())throw Exception("TCBS empty"); out.takeLast(10) }
    private suspend fun yahoo(code:String,exchange:String)=withContext(Dispatchers.IO){ val symbols=when(exchange){"HOSE"->listOf("$code.VN","$code.HM");"HNX"->listOf("$code.HN","$code.VN");else->listOf("$code.VN","$code.HM","$code.HN")}; for(sym in symbols){try{ val r=JSONObject(get("https://query1.finance.yahoo.com/v8/finance/chart/$sym?range=3mo&interval=1d")).getJSONObject("chart").getJSONArray("result").getJSONObject(0); val ts=r.getJSONArray("timestamp"); val q=r.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0); val closes=q.getJSONArray("close"); val vols=q.optJSONArray("volume"); val out=mutableListOf<Bar>(); for(i in 0 until ts.length()){val c=closes.optDouble(i,0.0); if(c>0){val d=java.time.Instant.ofEpochMilli(ts.getLong(i)*1000).atZone(ZoneOffset.UTC).toLocalDate().toString(); out.add(Bar(d,c,vols?.optDouble(i,0.0)?:0.0))}}; if(out.isNotEmpty())return@withContext out.takeLast(10) }catch(_:Exception){} }; throw Exception("Yahoo empty") }

    private fun deviceCode():DeviceCode{ val j=postForm("https://github.com/login/device/code", FormBody.Builder().add("client_id",GitHubConfig.CLIENT_ID).add("scope","gist").build()); if(j.has("error"))throw Exception(j.optString("error_description",j.optString("error"))); return DeviceCode(j.getString("device_code"),j.getString("user_code"),j.getString("verification_uri"),j.optInt("expires_in",900),j.optInt("interval",5)) }
    private fun pollToken(d:DeviceCode):String{ var interval=d.interval.coerceAtLeast(5); val end=System.currentTimeMillis()+d.expires*1000L; while(System.currentTimeMillis()<end){ Thread.sleep(interval*1000L); val j=postForm("https://github.com/login/oauth/access_token", FormBody.Builder().add("client_id",GitHubConfig.CLIENT_ID).add("device_code",d.device).add("grant_type","urn:ietf:params:oauth:grant-type:device_code").build()); if(j.has("access_token"))return j.getString("access_token"); when(val e=j.optString("error")){"authorization_pending"->{};"slow_down"->interval+=5;"access_denied"->throw Exception("Bạn đã từ chối cấp quyền");"expired_token"->throw Exception("Mã hết hạn");else->if(e.isNotBlank())throw Exception(j.optString("error_description",e))} }; throw Exception("Hết thời gian chờ") }
    private fun postForm(url:String, form:FormBody):JSONObject{ val req=Request.Builder().url(url).post(form).header("Accept","application/json").header("User-Agent","VNStockAndroid/2.0").build(); http.newCall(req).execute().use{res->val t=res.body?.string()?:""; if(!res.isSuccessful)throw Exception("HTTP ${res.code}: $t"); return JSONObject(t)} }

    private fun github(method:String,url:String,token:String,body:JSONObject?=null):JSONObject{ val media="application/json; charset=utf-8".toMediaType(); val b=Request.Builder().url(url).header("Authorization","Bearer $token").header("Accept","application/vnd.github+json").header("User-Agent","VNStockAndroid/2.0"); when(method){"GET"->b.get();"POST"->b.post((body?:JSONObject()).toString().toRequestBody(media));"PATCH"->b.patch((body?:JSONObject()).toString().toRequestBody(media))}; http.newCall(b.build()).execute().use{res->val t=res.body?.string()?:""; if(!res.isSuccessful)throw Exception("GitHub HTTP ${res.code}: $t"); return JSONObject(t)} }
    private fun gistId(token:String):String?{ val saved=prefs().getString("gist_id",null); if(!saved.isNullOrBlank())return saved; val req=Request.Builder().url("https://api.github.com/gists?per_page=100").header("Authorization","Bearer $token").header("Accept","application/vnd.github+json").header("User-Agent","VNStockAndroid/2.0").build(); http.newCall(req).execute().use{res->val arr=JSONArray(res.body?.string()?:"[]"); for(i in 0 until arr.length()){val o=arr.getJSONObject(i); val files=o.optJSONObject("files"); if(o.optString("description")==GitHubConfig.GIST_DESCRIPTION || files?.has(GitHubConfig.GIST_FILE)==true){val id=o.getString("id"); prefs().edit().putString("gist_id",id).apply(); return id}}}; return null }
    private fun createGist(token:String, content:String):String{ val files=JSONObject().put(GitHubConfig.GIST_FILE,JSONObject().put("content",content)); val body=JSONObject().put("description",GitHubConfig.GIST_DESCRIPTION).put("public",false).put("files",files); val id=github("POST","https://api.github.com/gists",token,body).getString("id"); prefs().edit().putString("gist_id",id).apply(); return id }
    private fun saveGist(token:String){ val content=gson.toJson(state); val id=gistId(token)?:createGist(token,content); val files=JSONObject().put(GitHubConfig.GIST_FILE,JSONObject().put("content",content)); github("PATCH","https://api.github.com/gists/$id",token,JSONObject().put("files",files)) }
    private fun readGist(token:String):AppState?{ val id=gistId(token)?:return null; val res=github("GET","https://api.github.com/gists/$id",token); val file=res.optJSONObject("files")?.optJSONObject(GitHubConfig.GIST_FILE)?:return null; var content=file.optString("content"); if(content.isBlank()){val raw=file.optString("raw_url"); if(raw.isNotBlank())content=get(raw,token)}; if(content.isBlank())return null; return gson.fromJson(content,AppState::class.java) }
    private fun saveCloud(){ saveLocal(); val t=token(); if(offline||t==null){toast("Đã lưu local");return}; scope.launch{try{withContext(Dispatchers.IO){saveGist(t)}; toast("Đã lưu GitHub Gist")}catch(e:Exception){toast("Lỗi lưu Gist: ${e.message}")}} }
    private fun loadGist(){ val t=token()?:return; scope.launch{try{toast("Đang tải Gist..."); val s=withContext(Dispatchers.IO){readGist(t)}; if(s!=null){state=s; ensure(); saveLocal(); toast("Đã tải Gist"); showMain()}else{withContext(Dispatchers.IO){saveGist(t)}; toast("Đã tạo Gist mới")}}catch(e:Exception){toast("Lỗi Gist: ${e.message}")}} }

    private fun calcRows():List<CalcRow>{ val arr=state.holdings.map{h-> val p=state.prices[h.code]?:Price(h.manualPrice,source="Thủ công"); val value=h.qty*p.price; val capital=h.qty*h.cost; val day=h.qty*(if(p.prevClose>0)p.price-p.prevClose else p.change); CalcRow(h,p,value,capital,value-capital,if(capital>0)(value-capital)/capital else 0.0,day)}; return arr }
    private fun num(o:JSONObject,vararg keys:String):Double{ for(k in keys) if(o.has(k)&&!o.isNull(k)) return o.optDouble(k,0.0); return 0.0 }
    private fun get(url:String, token:String?=null):String{ val b=Request.Builder().url(url).header("User-Agent","VNStockAndroid/2.0").header("Accept","application/json,text/plain,*/*"); if(token!=null)b.header("Authorization","Bearer $token"); http.newCall(b.build()).execute().use{res-> if(!res.isSuccessful)throw Exception("HTTP ${res.code}"); return res.body?.string()?:""} }
    private fun token()=prefs().getString("token",null); private fun saveToken(t:String)=prefs().edit().putString("token",t).apply(); private fun clearToken()=prefs().edit().clear().apply(); private fun prefs()=getSharedPreferences("github_auth",Context.MODE_PRIVATE)
    private fun loadLocal(){ val s=getPreferences(Context.MODE_PRIVATE).getString("state",null); if(!s.isNullOrBlank())runCatching{state=gson.fromJson(s,AppState::class.java)?:AppState(); ensure()} }
    private fun saveLocal(){ getPreferences(Context.MODE_PRIVATE).edit().putString("state",gson.toJson(state)).apply() }
    private fun ensure(){ if(state.holdings==null)state.holdings=mutableListOf(); if(state.prices==null)state.prices=mutableMapOf() }
    private fun shareBackup(){ val send=Intent(Intent.ACTION_SEND); send.type="application/json"; send.putExtra(Intent.EXTRA_TEXT,gson.toJson(state)); startActivity(Intent.createChooser(send,"Chia sẻ backup")) }

    private fun money(v:Double)=NumberFormat.getInstance(Locale("vi","VN")).format(v); private fun pct(v:Double)=String.format(Locale.US,"%.2f%%",v*100.0); private fun trim(v:Double)=if(v%1.0==0.0)v.toLong().toString() else v.toString(); private fun num(s:String)=s.replace(",","").trim().toDoubleOrNull()?:0.0; private fun clean(s:String)=s.trim().uppercase(Locale.US).replace(Regex("[^A-Z0-9]"),""); private fun today()=LocalDate.now().toString(); private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    private fun primary()=Color.rgb(15,118,110); private fun blue()=Color.rgb(37,99,235); private fun red()=Color.rgb(220,38,38); private fun green()=Color.rgb(22,163,74); private fun gray()=Color.rgb(71,84,103)
    private fun vertical()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; private fun horiz()=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}; private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt(); private fun weight()=LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(dp(4),dp(4),dp(4),dp(4))}
    private fun card()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.WHITE);setPadding(dp(14),dp(14),dp(14),dp(14));elevation=dp(2).toFloat();layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(10),dp(10),dp(10),dp(10))}}
    private fun btn(t:String,c:Int)=Button(this).apply{text=t;setTextColor(Color.WHITE);setBackgroundColor(c);isAllCaps=false}; private fun input(h:String)=EditText(this).apply{hint=h;setSingleLine(true);setPadding(dp(10),dp(8),dp(10),dp(8))}
    private fun txt(s:String,sp:Int,c:Int,bold:Boolean=false)=TextView(this).apply{text=s;textSize=sp.toFloat();setTextColor(c);setPadding(dp(4),dp(4),dp(4),dp(4));if(bold)typeface=android.graphics.Typeface.DEFAULT_BOLD}; private fun title(s:String)=txt(s,22,Color.rgb(16,24,40),true); private fun sub(s:String)=txt(s,18,Color.rgb(16,24,40),true); private fun label(s:String)=txt(s,12,Color.DKGRAY); private fun line()=android.view.View(this).apply{setBackgroundColor(Color.rgb(228,231,236));layoutParams=LinearLayout.LayoutParams(-1,1)}
    private fun metric(l:String,v:String,signed:Double?=null)=vertical().apply{setPadding(dp(10),dp(10),dp(10),dp(10));setBackgroundColor(Color.rgb(249,250,251));addView(txt(l,12,Color.DKGRAY));addView(txt(v,17,signed?.let{if(it>=0)green()else red()}?:Color.rgb(16,24,40),true))}
}

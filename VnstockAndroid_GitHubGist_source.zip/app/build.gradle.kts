plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rong9dau.vnstock"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.rong9dau.vnstock"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0.0-github"
    }
}

dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.google.code.gson:gson:2.11.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
